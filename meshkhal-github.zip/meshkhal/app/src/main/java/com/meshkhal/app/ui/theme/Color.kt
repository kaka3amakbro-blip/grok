package com.meshkhal.app.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Islamic-inspired palette
val EmeraldDeep = Color(0xFF0B3D2E)
val Emerald = Color(0xFF0F5C45)
val EmeraldLight = Color(0xFF1A7A5C)
val Gold = Color(0xFFD4AF37)
val GoldSoft = Color(0xFFE8D5A3)
val Cream = Color(0xFFF8F1E3)
val Sand = Color(0xFFE8DFD0)
val Night = Color(0xFF0A1628)
val NightSoft = Color(0xFF132337)
val Mist = Color(0xFFB8C5D6)

// Light scheme
val LightPrimary = Emerald
val LightOnPrimary = Color.White
val LightSecondary = Gold
val LightOnSecondary = Night
val LightBackground = Cream
val LightSurface = Color.White
val LightOnBackground = Night
val LightOnSurface = Night

// Dark scheme
val DarkPrimary = EmeraldLight
val DarkOnPrimary = Night
val DarkSecondary = GoldSoft
val DarkOnSecondary = Night
val DarkBackground = Night
val DarkSurface = NightSoft
val DarkOnBackground = Cream
val DarkOnSurface = Cream
