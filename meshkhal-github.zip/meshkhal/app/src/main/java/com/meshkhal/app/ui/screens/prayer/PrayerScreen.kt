package com.meshkhal.app.ui.screens.prayer

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.outlined.Mosque
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.meshkhal.app.data.model.City
import com.meshkhal.app.data.model.PrayerName
import com.meshkhal.app.data.model.PrayerTime
import com.meshkhal.app.data.model.TimeSource
import com.meshkhal.app.ui.components.FadeInItem
import com.meshkhal.app.ui.components.PulseScale
import com.meshkhal.app.ui.components.ShimmerEffect
import com.meshkhal.app.ui.theme.Emerald
import com.meshkhal.app.ui.theme.Gold
import com.meshkhal.app.ui.theme.GoldSoft
import com.meshkhal.app.ui.components.premiumClickable

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrayerScreen(
    viewModel: PrayerViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var showCityPicker by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState()

    Box(modifier = Modifier.fillMaxSize()) {
        // Dynamic background gradient
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.background,
                            MaterialTheme.colorScheme.surface.copy(alpha = 0.8f),
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                        )
                    )
                )
        )

        val isRefreshing = uiState.isLoading && uiState.dailyTimes != null
        val pullState = rememberPullToRefreshState()

        PullToRefreshBox(
            isRefreshing = isRefreshing,
            onRefresh = viewModel::refresh,
            state = pullState,
            modifier = Modifier.fillMaxSize()
        ) {
            when {
                uiState.isLoading && uiState.dailyTimes == null -> {
                    LoadingContent()
                }
                uiState.error != null -> {
                    ErrorContent(message = uiState.error!!, onRetry = viewModel::refresh)
                }
                else -> {
                    PrayerContent(
                        uiState = uiState,
                        onCityClick = { showCityPicker = true },
                        onRefresh = viewModel::refresh
                    )
                }
            }
        }

        if (showCityPicker) {
            ModalBottomSheet(
                onDismissRequest = { showCityPicker = false },
                sheetState = sheetState,
                containerColor = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
            ) {
                CityPickerContent(
                    cities = uiState.availableCities,
                    selectedId = uiState.selectedCity?.id,
                    onSelect = {
                        viewModel.selectCity(it)
                        showCityPicker = false
                    }
                )
            }
        }
    }
}

@Composable
private fun LoadingContent() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(80.dp))
        ShimmerEffect(modifier = Modifier.fillMaxWidth().height(180.dp))
        ShimmerEffect(modifier = Modifier.fillMaxWidth().height(28.dp))
        repeat(6) {
            ShimmerEffect(modifier = Modifier.fillMaxWidth().height(64.dp))
        }
    }
}

@Composable
private fun ErrorContent(message: String, onRetry: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = message, color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(16.dp))
        IconButton(onClick = onRetry) {
            Icon(Icons.Default.Refresh, contentDescription = "Retry")
        }
    }
}

@Composable
private fun PrayerContent(
    uiState: com.meshkhal.app.data.model.PrayerUiState,
    onCityClick: () -> Unit,
    onRefresh: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            FadeInItem(index = 0) {
                HeaderSection(
                    city = uiState.selectedCity,
                    source = uiState.dailyTimes?.source,
                    onCityClick = onCityClick,
                    onRefresh = onRefresh
                )
            }
        }

        item {
            FadeInItem(index = 1) {
                NextPrayerHero(
                    nextPrayer = uiState.nextPrayer,
                    countdownSeconds = uiState.countdownSeconds
                )
            }
        }

        item {
            FadeInItem(index = 2) {
                Text(
                    text = "کاتەکانی نوێژ / أوقات الصلاة",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
                    modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
                )
            }
        }

        uiState.dailyTimes?.times?.let { times ->
            itemsIndexed(times) { index, prayer ->
                FadeInItem(index = index + 3) {
                    PrayerTimeRow(
                        prayer = prayer,
                        isNext = uiState.nextPrayer?.name == prayer.name
                    )
                }
            }
        }

        item {
            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun HeaderSection(
    city: City?,
    source: TimeSource?,
    onCityClick: () -> Unit,
    onRefresh: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.clickable(onClick = onCityClick)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = Gold,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    text = city?.nameKu ?: "—",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                text = when (source) {
                    TimeSource.OFFICIAL -> "خشتەی فەرمی · Official"
                    TimeSource.CALCULATED -> "حسابکراو · Calculated"
                    null -> ""
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        IconButton(onClick = onRefresh) {
            Icon(
                imageVector = Icons.Default.Refresh,
                contentDescription = "Refresh",
                tint = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
private fun NextPrayerHero(
    nextPrayer: PrayerTime?,
    countdownSeconds: Long
) {
    val hours = countdownSeconds / 3600
    val minutes = (countdownSeconds % 3600) / 60
    val seconds = countdownSeconds % 60

    PulseScale(targetScale = 1.02f) { scale ->
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .scale(scale),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color.Transparent
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Emerald.copy(alpha = 0.9f),
                                Emerald.copy(alpha = 0.7f),
                                Gold.copy(alpha = 0.25f)
                            )
                        ),
                        shape = RoundedCornerShape(28.dp)
                    )
                    .padding(28.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "نوێژی داهاتوو · الصلاة القادمة",
                        style = MaterialTheme.typography.labelLarge,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                    Spacer(Modifier.height(8.dp))

                    AnimatedContent(
                        targetState = nextPrayer?.name,
                        transitionSpec = {
                            (fadeIn() + scaleIn(initialScale = 0.9f)) togetherWith
                                    (fadeOut() + scaleOut(targetScale = 0.9f))
                        },
                        label = "prayerName"
                    ) { name ->
                        Text(
                            text = prayerNameLocalized(name),
                            style = MaterialTheme.typography.displayLarge,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = nextPrayer?.time ?: "--:--",
                        style = MaterialTheme.typography.headlineMedium,
                        color = GoldSoft
                    )

                    Spacer(Modifier.height(20.dp))

                    // Countdown
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CountdownUnit(value = hours, label = "کاتژمێر")
                        Text(":", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        CountdownUnit(value = minutes, label = "خولەک")
                        Text(":", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        CountdownUnit(value = seconds, label = "چرکە")
                    }
                }
            }
        }
    }
}

@Composable
private fun CountdownUnit(value: Long, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "%02d".format(value),
            style = MaterialTheme.typography.headlineMedium,
            color = Color.White,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = Color.White.copy(alpha = 0.7f),
            fontSize = 11.sp
        )
    }
}

@Composable
private fun PrayerTimeRow(
    prayer: PrayerTime,
    isNext: Boolean
) {
    val scale by animateFloatAsState(
        targetValue = if (isNext) 1.03f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "rowScale"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isNext)
                MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
            else
                MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = if (isNext) 6.dp else 2.dp
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(
                            if (isNext) Gold.copy(alpha = 0.2f)
                            else MaterialTheme.colorScheme.surfaceVariant
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Mosque,
                        contentDescription = null,
                        tint = if (isNext) Gold else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(
                        text = prayerNameLocalized(prayer.name),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = if (isNext) FontWeight.Bold else FontWeight.Medium
                    )
                    if (isNext) {
                        Text(
                            text = "داهاتوو · Next",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Gold
                        )
                    }
                }
            }

            Text(
                text = prayer.time,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold,
                color = if (isNext) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun CityPickerContent(
    cities: List<City>,
    selectedId: String?,
    onSelect: (City) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 32.dp)
    ) {
        Text(
            text = "هەڵبژاردنی شار · اختر المدينة",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp)
        )
        cities.forEach { city ->
            val selected = city.id == selectedId
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelect(city) }
                    .background(
                        if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                        else Color.Transparent
                    )
                    .padding(horizontal = 24.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = city.nameKu,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = city.nameEn,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

private fun prayerNameLocalized(name: PrayerName?): String {
    return when (name) {
        PrayerName.FAJR -> "بەیانی · الفجر"
        PrayerName.SUNRISE -> "خۆرھەڵاتن · الشروق"
        PrayerName.DHUHR -> "نیوەڕۆ · الظهر"
        PrayerName.ASR -> "عەسر · العصر"
        PrayerName.MAGHRIB -> "مەغریب · المغرب"
        PrayerName.ISHA -> "عیشا · العشاء"
        null -> "—"
    }
}
