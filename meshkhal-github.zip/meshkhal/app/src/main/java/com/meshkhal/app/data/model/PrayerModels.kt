package com.meshkhal.app.data.model

import kotlinx.serialization.Serializable

@Serializable
data class City(
    val id: String,
    val nameKu: String,
    val nameAr: String,
    val nameEn: String,
    val latitude: Double,
    val longitude: Double,
    val timezone: String = "Asia/Baghdad",
    val hasOfficialTimes: Boolean = false
)

@Serializable
data class PrayerTime(
    val name: PrayerName,
    val time: String, // HH:mm
    val isNext: Boolean = false,
    val isPassed: Boolean = false
)

enum class PrayerName {
    FAJR, SUNRISE, DHUHR, ASR, MAGHRIB, ISHA
}

@Serializable
data class DailyPrayerTimes(
    val date: String,
    val hijriDate: String,
    val cityId: String,
    val times: List<PrayerTime>,
    val source: TimeSource
)

enum class TimeSource {
    OFFICIAL, CALCULATED
}

data class PrayerUiState(
    val isLoading: Boolean = true,
    val selectedCity: City? = null,
    val dailyTimes: DailyPrayerTimes? = null,
    val nextPrayer: PrayerTime? = null,
    val countdownSeconds: Long = 0L,
    val availableCities: List<City> = emptyList(),
    val error: String? = null,
    val isDarkSky: Boolean = false
)
