package com.meshkhal.app.ui.screens.quran

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.outlined.Book
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.meshkhal.app.data.local.quran.SampleAyahs
import com.meshkhal.app.data.model.MushafStyle
import com.meshkhal.app.data.model.Surah
import com.meshkhal.app.ui.components.FadeInItem
import com.meshkhal.app.ui.theme.Emerald
import com.meshkhal.app.ui.theme.Gold

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AyahReaderScreen(
    surah: Surah,
    onBack: () -> Unit
) {
    var currentMushaf by remember { mutableStateOf(MushafStyle.default()) }
    var menuExpanded by remember { mutableStateOf(false) }
    val ayahs = remember(surah.number) { SampleAyahs.forSurah(surah.number) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(surah.nameAr, fontWeight = FontWeight.Bold)
                        Text(
                            "${surah.nameKu} · ${currentMushaf.nameEn}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { menuExpanded = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Mushaf styles")
                    }
                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false }
                    ) {
                        MushafStyle.entries.forEach { style ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(style.nameKu, fontWeight = FontWeight.Medium)
                                        Text(style.nameEn, style = MaterialTheme.typography.bodySmall)
                                    }
                                },
                                onClick = {
                                    currentMushaf = style
                                    menuExpanded = false
                                },
                                leadingIcon = {
                                    if (style == currentMushaf) {
                                        Icon(Icons.Outlined.Book, null, tint = Gold)
                                    }
                                }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Emerald.copy(alpha = 0.08f)
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                FadeInItem(index = 0) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Gold.copy(alpha = 0.12f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Outlined.Book, null, tint = Gold)
                            Column(modifier = Modifier.padding(start = 12.dp)) {
                                Text(currentMushaf.nameKu, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "${currentMushaf.linesPerPage} هێڵ · ${currentMushaf.totalPages} لاپەڕە · ${currentMushaf.script}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
            }

            items(ayahs, key = { it.number }) { ayah ->
                FadeInItem(index = ayah.number) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp)
                        ) {
                            Text(
                                text = "${ayah.number}",
                                color = Gold,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = ayah.ar,
                                style = MaterialTheme.typography.headlineSmall.copy(
                                    fontFamily = FontFamily.Serif,
                                    fontSize = 26.sp,
                                    lineHeight = 42.sp
                                ),
                                textAlign = TextAlign.Right,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(12.dp))
                            Text(
                                text = ayah.ku,
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    text = "النص الكامل لباقي السور يُحمّل من حزمة القرآن الموثوقة (مثل Tanzil) في الإصدارات القادمة.\nFull text for remaining surahs will be loaded from a trusted offline package.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 16.dp)
                )
            }
        }
    }
}
