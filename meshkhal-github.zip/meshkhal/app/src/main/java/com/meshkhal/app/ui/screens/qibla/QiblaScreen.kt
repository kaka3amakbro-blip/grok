package com.meshkhal.app.ui.screens.qibla

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.meshkhal.app.data.local.KurdistanCities
import com.meshkhal.app.ui.components.FadeInItem
import com.meshkhal.app.ui.theme.Emerald
import com.meshkhal.app.ui.theme.Gold
import com.meshkhal.app.util.QiblaCalculator
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun QiblaScreen() {
    // For demo we use Slemani coordinates. In production use device location + sensor.
    val city = KurdistanCities.default()
    val qiblaBearing = remember {
        QiblaCalculator.calculateBearing(city.latitude, city.longitude).toFloat()
    }

    // Simulated device azimuth (in real app: use SensorManager TYPE_ROTATION_VECTOR or TYPE_ORIENTATION)
    var deviceAzimuth by remember { mutableFloatStateOf(0f) }
    // For demo animation we can slowly rotate, but keep static for clarity.
    val needleRotation by animateFloatAsState(
        targetValue = qiblaBearing - deviceAzimuth,
        animationSpec = spring(),
        label = "qiblaNeedle"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        FadeInItem(index = 0) {
            Text(
                text = "قیبلە · القبلة · Qibla",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
        }
        FadeInItem(index = 1) {
            Text(
                text = city.nameKu + " · " + city.nameEn,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(Modifier.height(40.dp))

        FadeInItem(index = 2) {
            Box(
                modifier = Modifier
                    .size(280.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Emerald.copy(alpha = 0.25f),
                                MaterialTheme.colorScheme.surface
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                // Compass dial
                Canvas(modifier = Modifier.size(260.dp)) {
                    val radius = size.minDimension / 2
                    val center = Offset(size.width / 2, size.height / 2)

                    // Outer ring
                    drawCircle(
                        color = Gold.copy(alpha = 0.4f),
                        radius = radius,
                        style = Stroke(width = 4.dp.toPx())
                    )
                    // Inner ring
                    drawCircle(
                        color = Emerald.copy(alpha = 0.3f),
                        radius = radius * 0.85f,
                        style = Stroke(width = 2.dp.toPx())
                    )

                    // Cardinal marks
                    for (i in 0 until 12) {
                        val angle = Math.toRadians((i * 30).toDouble())
                        val start = Offset(
                            center.x + (radius * 0.75f * sin(angle)).toFloat(),
                            center.y - (radius * 0.75f * cos(angle)).toFloat()
                        )
                        val end = Offset(
                            center.x + (radius * 0.9f * sin(angle)).toFloat(),
                            center.y - (radius * 0.9f * cos(angle)).toFloat()
                        )
                        drawLine(
                            color = if (i % 3 == 0) Gold else Color.Gray.copy(alpha = 0.5f),
                            start = start,
                            end = end,
                            strokeWidth = if (i % 3 == 0) 3.dp.toPx() else 1.5.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    }
                }

                // Qibla needle
                Box(
                    modifier = Modifier
                        .size(200.dp)
                        .rotate(needleRotation),
                    contentAlignment = Alignment.TopCenter
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val center = Offset(size.width / 2, size.height / 2)
                        // Needle pointing up (Qibla)
                        drawLine(
                            color = Gold,
                            start = center,
                            end = Offset(center.x, 20f),
                            strokeWidth = 8.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                        // Tail
                        drawLine(
                            color = Emerald.copy(alpha = 0.6f),
                            start = center,
                            end = Offset(center.x, size.height - 20f),
                            strokeWidth = 5.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                        // Center dot
                        drawCircle(color = Gold, radius = 12.dp.toPx(), center = center)
                    }
                }
            }
        }

        Spacer(Modifier.height(32.dp))

        FadeInItem(index = 3) {
            Text(
                text = "ئاڕاستە: ${"%.1f".format(qiblaBearing)}°",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold,
                color = Gold
            )
        }
        FadeInItem(index = 4) {
            Text(
                text = "لە ${city.nameKu} بۆ کەعبە",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(Modifier.height(24.dp))

        FadeInItem(index = 5) {
            Text(
                text = "تێبینی: بۆ کارکردنی تەواو پێویستە هەستەوەری قطب‌نما و شوێن چالاک بکرێت.\n(In production: use real magnetometer + location sensors)",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }
    }
}
