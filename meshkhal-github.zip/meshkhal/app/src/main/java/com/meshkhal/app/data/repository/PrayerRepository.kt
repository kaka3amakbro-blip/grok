package com.meshkhal.app.data.repository

import com.meshkhal.app.data.local.KurdistanCities
import com.meshkhal.app.data.local.PrayerCalculator
import com.meshkhal.app.data.model.City
import com.meshkhal.app.data.model.DailyPrayerTimes
import com.meshkhal.app.data.model.PrayerName
import com.meshkhal.app.data.model.PrayerTime
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PrayerRepository @Inject constructor() {

    fun getCities(): List<City> = KurdistanCities.all

    fun getDefaultCity(): City = KurdistanCities.default()

    fun getDailyTimes(city: City): DailyPrayerTimes {
        return PrayerCalculator.buildDailyTimes(
            cityId = city.id,
            latitude = city.latitude,
            longitude = city.longitude,
            preferOfficial = city.hasOfficialTimes
        )
    }

    fun observeNextPrayerAndCountdown(city: City): Flow<Pair<PrayerTime?, Long>> = flow {
        while (true) {
            val daily = getDailyTimes(city)
            val now = LocalTime.now()
            val formatter = DateTimeFormatter.ofPattern("HH:mm")

            var next: PrayerTime? = null
            var seconds: Long = 0

            for (prayer in daily.times.filter { it.name != PrayerName.SUNRISE }) {
                val prayerTime = LocalTime.parse(prayer.time, formatter)
                if (prayerTime.isAfter(now)) {
                    next = prayer.copy(isNext = true)
                    seconds = ChronoUnit.SECONDS.between(now, prayerTime)
                    break
                }
            }

            // If all passed, next is Fajr tomorrow (simplified)
            if (next == null) {
                val fajr = daily.times.first { it.name == PrayerName.FAJR }
                next = fajr.copy(isNext = true)
                val fajrTime = LocalTime.parse(fajr.time, formatter)
                seconds = ChronoUnit.SECONDS.between(now, fajrTime.plusHours(24))
            }

            emit(next to seconds)
            delay(1000L)
        }
    }
}
