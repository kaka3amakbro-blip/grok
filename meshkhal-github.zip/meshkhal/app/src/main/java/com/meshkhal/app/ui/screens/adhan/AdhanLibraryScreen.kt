package com.meshkhal.app.ui.screens.adhan

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.meshkhal.app.data.model.AdhanLibrary
import com.meshkhal.app.data.model.Muazzin
import com.meshkhal.app.ui.components.FadeInItem
import com.meshkhal.app.ui.theme.Gold
import com.meshkhal.app.ui.components.premiumClickable

@Composable
fun AdhanLibraryScreen() {
    var muazzins by remember { mutableStateOf(AdhanLibrary.popularMuazzins) }
    var downloadingId by remember { mutableStateOf<String?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(20.dp)) {
            FadeInItem(index = 0) {
                Text(
                    text = "کتێبخانەی بانگ · مكتبة الأذان",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            FadeInItem(index = 1) {
                Text(
                    text = "Adhan Library · ${muazzins.size} مؤذن",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            itemsIndexed(muazzins, key = { _, m -> m.id }) { index, muazzin ->
                FadeInItem(index = index) {
                    MuazzinCard(
                        muazzin = muazzin,
                        isDownloading = downloadingId == muazzin.id,
                        onDownload = {
                            // Simulate download
                            downloadingId = muazzin.id
                            // In real app: start WorkManager / DownloadManager
                            muazzins = muazzins.map {
                                if (it.id == muazzin.id) it.copy(isDownloaded = true) else it
                            }
                            downloadingId = null
                        },
                        onPlay = { /* MediaPlayer or ExoPlayer */ }
                    )
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun MuazzinCard(
    muazzin: Muazzin,
    isDownloading: Boolean,
    onDownload: () -> Unit,
    onPlay: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = muazzin.nameKu,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "${muazzin.nameAr} · ${muazzin.nameEn}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "${muazzin.country} · ${muazzin.style} · ${muazzin.durationSeconds / 60}:${"%02d".format(muazzin.durationSeconds % 60)}",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (isDownloading) {
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
            }

            if (muazzin.isDownloaded) {
                Icon(
                    imageVector = Icons.Outlined.CheckCircle,
                    contentDescription = "Downloaded",
                    tint = Gold,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(Modifier.width(8.dp))
                IconButton(onClick = onPlay) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = MaterialTheme.colorScheme.primary)
                }
            } else {
                IconButton(onClick = onDownload) {
                    Icon(Icons.Default.Download, contentDescription = "Download", tint = Gold)
                }
            }
        }
    }
}
