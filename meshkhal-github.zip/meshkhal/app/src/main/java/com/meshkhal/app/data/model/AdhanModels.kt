package com.meshkhal.app.data.model

/**
 * Adhan / Muazzin library models.
 * Supports downloadable high-quality Adhans.
 */
data class Muazzin(
    val id: String,
    val nameAr: String,
    val nameKu: String,
    val nameEn: String,
    val country: String,
    val style: String,          // "Haramain", "Kurdish", "Egyptian", "Turkish"...
    val durationSeconds: Int,
    val isDownloaded: Boolean = false,
    val fileSizeMb: Float = 0f,
    val sampleUrl: String? = null,   // for streaming/preview
    val downloadUrl: String? = null
)

object AdhanLibrary {
    val popularMuazzins = listOf(
        Muazzin("makkah_sudais", "عبد الرحمن السديس", "عەبدولڕەحمان سودەیس", "Abdul Rahman Al-Sudais", "Saudi", "Haramain", 210, fileSizeMb = 3.2f),
        Muazzin("makkah_shuraim", "سعود الشريم", "سەعود شورەیم", "Saud Al-Shuraim", "Saudi", "Haramain", 195, fileSizeMb = 2.9f),
        Muazzin("madinah_budair", "علي بن عبد الرحمن الحديفي", "عەلی حودەیفی", "Ali Al-Hudhaifi", "Saudi", "Haramain", 220, fileSizeMb = 3.4f),
        Muazzin("madinah_ayyub", "عبد المحسن القاسم", "عەبدولموحسین قاسم", "Abdulmohsen Al-Qasim", "Saudi", "Haramain", 205, fileSizeMb = 3.1f),
        Muazzin("egypt_minshawi", "محمد صديق المنشاوي", "موحەممەد سدیق مەنشاوی", "Muhammad Siddiq Al-Minshawi", "Egypt", "Egyptian", 240, fileSizeMb = 3.6f),
        Muazzin("egypt_abdulbasit", "عبد الباسط عبد الصمد", "عەبدولباست عەبدولسەمەد", "Abdul Basit Abdus Samad", "Egypt", "Egyptian", 255, fileSizeMb = 3.8f),
        Muazzin("kuwait_refai", "مشاري راشد العفاسي", "میشاری ڕاشید عەفاسی", "Mishary Rashid Alafasy", "Kuwait", "Modern", 200, fileSizeMb = 3.0f),
        Muazzin("turkey_classic", "أذان تركي تقليدي", "بانگی تورکی کلاسیک", "Classic Turkish Adhan", "Turkey", "Turkish", 180, fileSizeMb = 2.7f),
        Muazzin("kurdish_1", "مؤذن كردي 1", "بانگبێژی کوردی ١", "Kurdish Muazzin 1", "Kurdistan", "Kurdish", 190, fileSizeMb = 2.8f),
        Muazzin("kurdish_2", "مؤذن كردي 2", "بانگبێژی کوردی ٢", "Kurdish Muazzin 2", "Kurdistan", "Kurdish", 185, fileSizeMb = 2.7f),
        Muazzin("kurdish_3", "مؤذن كردي 3 (سلێمانی)", "بانگبێژی کوردی ٣ (سلێمانی)", "Kurdish Muazzin 3 (Slemani)", "Kurdistan", "Kurdish", 200, fileSizeMb = 3.0f),
        Muazzin("jerusalem", "أذان الأقصى", "بانگی ئەقسا", "Al-Aqsa Adhan", "Palestine", "Levant", 215, fileSizeMb = 3.2f),
        Muazzin("gentle_chime", "جرس هادئ", "زەنگی نەرم", "Gentle Chime", "—", "Silent", 15, fileSizeMb = 0.3f),
        Muazzin("short_beep", "تنبيه قصير", "ئاگاداری کورت", "Short Beep", "—", "Silent", 5, fileSizeMb = 0.1f)
    )
}
