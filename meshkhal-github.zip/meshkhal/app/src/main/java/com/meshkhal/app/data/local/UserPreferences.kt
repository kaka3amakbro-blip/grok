package com.meshkhal.app.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "meshkhal_prefs")

@Singleton
class UserPreferences @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val dataStore = context.dataStore

    val darkMode: Flow<Boolean> = dataStore.data.map { it[KEY_DARK] ?: false }
    val notificationsEnabled: Flow<Boolean> = dataStore.data.map { it[KEY_NOTIFICATIONS] ?: true }
    val selectedCityId: Flow<String> = dataStore.data.map { it[KEY_CITY] ?: "slemani" }
    val languageCode: Flow<String> = dataStore.data.map { it[KEY_LANG] ?: "ckb" }
    val selectedMuazzinId: Flow<String> = dataStore.data.map { it[KEY_MUAZZIN] ?: "makkah_sudais" }

    suspend fun setDarkMode(enabled: Boolean) {
        dataStore.edit { it[KEY_DARK] = enabled }
    }

    suspend fun setNotifications(enabled: Boolean) {
        dataStore.edit { it[KEY_NOTIFICATIONS] = enabled }
    }

    suspend fun setCityId(id: String) {
        dataStore.edit { it[KEY_CITY] = id }
    }

    suspend fun setLanguage(code: String) {
        dataStore.edit { it[KEY_LANG] = code }
    }

    suspend fun setMuazzin(id: String) {
        dataStore.edit { it[KEY_MUAZZIN] = id }
    }

    companion object {
        private val KEY_DARK = booleanPreferencesKey("dark_mode")
        private val KEY_NOTIFICATIONS = booleanPreferencesKey("notifications")
        private val KEY_CITY = stringPreferencesKey("city_id")
        private val KEY_LANG = stringPreferencesKey("language")
        private val KEY_MUAZZIN = stringPreferencesKey("muazzin_id")
    }
}
