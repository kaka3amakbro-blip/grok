package com.meshkhal.app.ui.screens.prayer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.meshkhal.app.data.local.KurdistanCities
import com.meshkhal.app.data.local.UserPreferences
import com.meshkhal.app.data.model.City
import com.meshkhal.app.data.model.PrayerUiState
import com.meshkhal.app.data.repository.PrayerRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PrayerViewModel @Inject constructor(
    private val repository: PrayerRepository,
    private val prefs: UserPreferences
) : ViewModel() {

    private val _uiState = MutableStateFlow(PrayerUiState())
    val uiState: StateFlow<PrayerUiState> = _uiState.asStateFlow()

    private var countdownJob: Job? = null

    init {
        loadInitial()
    }

    private fun loadInitial() {
        viewModelScope.launch {
            val cities = repository.getCities()
            val savedId = prefs.selectedCityId.first()
            val city = KurdistanCities.findById(savedId) ?: repository.getDefaultCity()
            _uiState.update {
                it.copy(
                    isLoading = false,
                    availableCities = cities,
                    selectedCity = city
                )
            }
            selectCity(city, persist = false)
        }
    }

    fun selectCity(city: City, persist: Boolean = true) {
        countdownJob?.cancel()
        _uiState.update { it.copy(isLoading = true, selectedCity = city, error = null) }

        viewModelScope.launch {
            try {
                if (persist) prefs.setCityId(city.id)
                val daily = repository.getDailyTimes(city)
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        dailyTimes = daily,
                        selectedCity = city
                    )
                }
                startCountdown(city)
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(isLoading = false, error = e.message ?: "Error loading times")
                }
            }
        }
    }

    private fun startCountdown(city: City) {
        countdownJob = viewModelScope.launch {
            repository.observeNextPrayerAndCountdown(city).collect { (next, seconds) ->
                _uiState.update {
                    it.copy(
                        nextPrayer = next,
                        countdownSeconds = seconds
                    )
                }
            }
        }
    }

    fun refresh() {
        _uiState.value.selectedCity?.let { selectCity(it, persist = false) }
    }
}
