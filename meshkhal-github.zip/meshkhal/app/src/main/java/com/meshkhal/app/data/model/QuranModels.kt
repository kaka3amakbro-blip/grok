package com.meshkhal.app.data.model

import kotlinx.serialization.Serializable

@Serializable
data class Surah(
    val number: Int,
    val nameAr: String,
    val nameKu: String,
    val nameEn: String,
    val nameTransliteration: String,
    val ayahCount: Int,
    val revelationType: RevelationType, // Meccan / Medinan
    val juzStart: Int = 1
)

enum class RevelationType {
    MECCAN, MEDINAN
}

@Serializable
data class Ayah(
    val number: Int,          // in surah
    val numberInQuran: Int,   // global 1-6236
    val textAr: String,
    val textKu: String? = null,
    val textEn: String? = null,
    val juz: Int = 1,
    val page: Int = 1,
    val sajda: Boolean = false
)

@Serializable
data class SurahWithAyahs(
    val surah: Surah,
    val ayahs: List<Ayah>
)

data class QuranUiState(
    val isLoading: Boolean = true,
    val surahs: List<Surah> = emptyList(),
    val selectedSurah: SurahWithAyahs? = null,
    val searchQuery: String = "",
    val bookmarks: Set<Int> = emptySet(), // ayah numbers in Quran
    val lastReadAyah: Int? = null,
    val error: String? = null,
    val downloadProgress: Float? = null // for future audio packs
)

// Famous reciters for later audio phase
enum class Reciter(val id: String, val nameAr: String, val nameEn: String) {
    AL_AFASY("afasy", "مشاري راشد العفاسي", "Mishary Rashid Alafasy"),
    ABDUL_BASIT("abdul_basit", "عبد الباسط عبد الصمد", "Abdul Basit"),
    MINSHAWI("minshawi", "محمد صديق المنشاوي", "Minshawi"),
    HUSARY("husary", "محمود خليل الحصري", "Al-Husary"),
    SUDAIS("sudais", "عبد الرحمن السديس", "Sudais")
}
