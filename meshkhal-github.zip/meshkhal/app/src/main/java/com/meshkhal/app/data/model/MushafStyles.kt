package com.meshkhal.app.data.model

/**
 * Different Mushaf (printed Quran) styles supported by the app.
 * These represent real-world popular layouts used by Muslims worldwide.
 */
enum class MushafStyle(
    val id: String,
    val nameAr: String,
    val nameKu: String,
    val nameEn: String,
    val linesPerPage: Int,
    val totalPages: Int,
    val script: ScriptType,
    val description: String
) {
    MADANI_15(
        "madani_15",
        "مصحف المدينة (عثمان طه)",
        "موسحەفی مەدینە (عثمان تاهە)",
        "Madani 15-line (Uthman Taha)",
        15, 604, ScriptType.UTHMANI,
        "Standard King Fahd Complex. Every page ends at end of ayah. Most widely used."
    ),
    INDOPAK_15(
        "indopak_15",
        "مصحف هندوباك 15 سطر",
        "موسحەفی هیندۆپاک ١٥ هێڵ",
        "Indo-Pak 15-line",
        15, 610, ScriptType.INDOPAK,
        "Popular in South Asia, UK, and many Kurdish communities who studied there."
    ),
    INDOPAK_13(
        "indopak_13",
        "مصحف هندوباك 13 سطر",
        "موسحەفی هیندۆپاک ١٣ هێڵ",
        "Indo-Pak 13-line",
        13, 849, ScriptType.INDOPAK,
        "Larger text, preferred by many for reading comfort."
    ),
    INDOPAK_16(
        "indopak_16",
        "مصحف هندوباك 16 سطر",
        "موسحەفی هیندۆپاک ١٦ هێڵ",
        "Indo-Pak 16-line",
        16, 548, ScriptType.INDOPAK,
        "Compact layout."
    ),
    TAJWEED_COLOR(
        "tajweed_color",
        "مصحف التجويد الملون",
        "موسحەفی تەجوید ڕەنگاو",
        "Color-coded Tajweed",
        15, 604, ScriptType.UTHMANI,
        "Letters colored according to Tajweed rules. Excellent for learners."
    ),
    WARSH(
        "warsh",
        "مصحف ورش",
        "موسحەفی وەرشی",
        "Warsh (riwayah)",
        15, 604, ScriptType.UTHMANI,
        "Different riwayah used in North and West Africa."
    ),
    QATAR(
        "qatar",
        "مصحف قطر",
        "موسحەفی قەتەر",
        "Qatar Mushaf",
        15, 604, ScriptType.UTHMANI,
        "Clean modern layout from Qatar."
    );

    companion object {
        fun default() = MADANI_15
    }
}

enum class ScriptType {
    UTHMANI,   // Madani / Arab world style
    INDOPAK    // South Asian / Nastaleeq influenced
}
