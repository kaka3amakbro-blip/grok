package com.meshkhal.app.data.local

import com.meshkhal.app.data.model.City

object KurdistanCities {
    val all = listOf(
        City("slemani", "سلێمانی", "السليمانية", "Sulaymaniyah", 35.5617, 45.4329, hasOfficialTimes = true),
        City("hawler", "هەولێر", "أربيل", "Erbil", 36.1911, 44.0092, hasOfficialTimes = true),
        City("duhok", "دهۆک", "دهوك", "Duhok", 36.8671, 42.9885, hasOfficialTimes = true),
        City("kirkuk", "کەرکوک", "كركوك", "Kirkuk", 35.4681, 44.3922, hasOfficialTimes = true),
        City("halabja", "هەڵەبجە", "حلبجة", "Halabja", 35.1778, 45.9861, hasOfficialTimes = true),
        City("ranya", "ڕانیە", "رانية", "Ranya", 36.2381, 44.8836, hasOfficialTimes = true),
        City("koya", "کۆیە", "كوي سنجق", "Koya", 36.0822, 44.6286, hasOfficialTimes = true),
        City("zakho", "زاخۆ", "زاخو", "Zakho", 37.1486, 42.6856, hasOfficialTimes = true),
        City("akre", "ئاکرێ", "عقرة", "Akre", 36.7411, 43.8931, hasOfficialTimes = true),
        City("chamchamal", "چەمچەماڵ", "جمجمال", "Chamchamal", 35.5333, 44.8333, hasOfficialTimes = true),
        City("qaladze", "قەڵادزێ", "قلعة دزة", "Qaladze", 36.1833, 45.1167, hasOfficialTimes = true),
        City("derbendikhan", "دەربەندیخان", "دربندخان", "Derbendikhan", 35.1167, 45.7000, hasOfficialTimes = true),
        City("kalar", "کەلار", "كلار", "Kalar", 34.6289, 45.3203, hasOfficialTimes = true),
        City("khanaqin", "خانەقین", "خانقين", "Khanaqin", 34.3481, 45.3919, hasOfficialTimes = true)
    )

    fun findById(id: String): City? = all.find { it.id == id }
    fun default(): City = all.first() // Slemani as default
}
