package com.meshkhal.app.ui.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.meshkhal.app.data.local.quran.SurahList
import com.meshkhal.app.ui.screens.adhan.AdhanLibraryScreen
import com.meshkhal.app.ui.screens.prayer.PrayerScreen
import com.meshkhal.app.ui.screens.qibla.QiblaScreen
import com.meshkhal.app.ui.screens.quran.AyahReaderScreen
import com.meshkhal.app.ui.screens.quran.QuranScreen
import com.meshkhal.app.ui.screens.settings.SettingsScreen

sealed class Screen(
    val route: String,
    val titleKu: String,
    val icon: ImageVector,
    val selectedIcon: ImageVector
) {
    data object Prayer : Screen("prayer", "کاتەکان", Icons.Outlined.Home, Icons.Filled.Home)
    data object Quran : Screen("quran", "قورئان", Icons.Outlined.MenuBook, Icons.Filled.MenuBook)
    data object Adhan : Screen("adhan", "بانگ", Icons.Outlined.Notifications, Icons.Filled.Notifications)
    data object Qibla : Screen("qibla", "قیبلە", Icons.Outlined.Explore, Icons.Filled.Explore)
    data object Settings : Screen("settings", "ڕێکخستن", Icons.Outlined.Settings, Icons.Filled.Settings)
}

val bottomNavItems = listOf(
    Screen.Prayer,
    Screen.Quran,
    Screen.Adhan,
    Screen.Qibla,
    Screen.Settings
)

@Composable
fun MeshkhalNavHost() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    Scaffold(
        bottomBar = {
            NavigationBar {
                bottomNavItems.forEach { screen ->
                    val selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true
                    NavigationBarItem(
                        icon = {
                            Icon(
                                imageVector = if (selected) screen.selectedIcon else screen.icon,
                                contentDescription = screen.titleKu
                            )
                        },
                        label = { Text(screen.titleKu) },
                        selected = selected,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Prayer.route,
            modifier = Modifier.padding(innerPadding),
            enterTransition = {
                fadeIn(animationSpec = tween(300)) + slideIntoContainer(
                    towards = AnimatedContentTransitionScope.SlideDirection.Start,
                    animationSpec = tween(300)
                )
            },
            exitTransition = {
                fadeOut(animationSpec = tween(300)) + slideOutOfContainer(
                    towards = AnimatedContentTransitionScope.SlideDirection.Start,
                    animationSpec = tween(300)
                )
            },
            popEnterTransition = {
                fadeIn(animationSpec = tween(300)) + slideIntoContainer(
                    towards = AnimatedContentTransitionScope.SlideDirection.End,
                    animationSpec = tween(300)
                )
            },
            popExitTransition = {
                fadeOut(animationSpec = tween(300)) + slideOutOfContainer(
                    towards = AnimatedContentTransitionScope.SlideDirection.End,
                    animationSpec = tween(300)
                )
            }
        ) {
            composable(Screen.Prayer.route) { PrayerScreen() }
            composable(Screen.Quran.route) {
                QuranScreen(
                    onSurahClick = { surah ->
                        navController.navigate("reader/${surah.number}")
                    }
                )
            }
            composable(Screen.Adhan.route) { AdhanLibraryScreen() }
            composable(Screen.Qibla.route) { QiblaScreen() }
            composable(Screen.Settings.route) { SettingsScreen() }

            composable(
                route = "reader/{surahNumber}",
                arguments = listOf(navArgument("surahNumber") { type = NavType.IntType })
            ) { backStackEntry ->
                val number = backStackEntry.arguments?.getInt("surahNumber") ?: 1
                val surah = SurahList.all.find { it.number == number } ?: SurahList.all.first()
                AyahReaderScreen(
                    surah = surah,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
