package com.meshkhal.app.data.local

import com.meshkhal.app.data.model.DailyPrayerTimes
import com.meshkhal.app.data.model.PrayerName
import com.meshkhal.app.data.model.PrayerTime
import com.meshkhal.app.data.model.TimeSource
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import kotlin.math.*

/**
 * Simple astronomical approximation for prayer times.
 * For production, replace with a proven library (e.g. Adhan library) or official tables.
 * Official times for major Kurdistan cities are preferred when available.
 */
object PrayerCalculator {

    private val timeFormatter = DateTimeFormatter.ofPattern("HH:mm")

    fun calculate(
        latitude: Double,
        longitude: Double,
        date: LocalDate = LocalDate.now(),
        fajrAngle: Double = 18.0,
        ishaAngle: Double = 17.0
    ): List<PrayerTime> {
        val dayOfYear = date.dayOfYear
        val timezoneOffset = 3.0 // Asia/Baghdad approx

        // Simplified solar calculation (not production-grade)
        val declination = 23.45 * sin(Math.toRadians(360.0 / 365.0 * (dayOfYear - 81)))
        val eqTime = 9.87 * sin(2 * Math.toRadians(360.0 / 365.0 * (dayOfYear - 81))) -
                7.53 * cos(Math.toRadians(360.0 / 365.0 * (dayOfYear - 81))) -
                1.5 * sin(Math.toRadians(360.0 / 365.0 * (dayOfYear - 81)))

        val latRad = Math.toRadians(latitude)
        val decRad = Math.toRadians(declination)

        fun hourAngle(angle: Double): Double {
            val cosH = (cos(Math.toRadians(angle)) - sin(latRad) * sin(decRad)) /
                    (cos(latRad) * cos(decRad))
            return Math.toDegrees(acos(cosH.coerceIn(-1.0, 1.0)))
        }

        val solarNoon = 12.0 - (longitude / 15.0) - (eqTime / 60.0) + timezoneOffset

        val fajrHA = hourAngle(180 - fajrAngle)
        val sunriseHA = hourAngle(90.833)
        val asrHA = hourAngle(90.0 + Math.toDegrees(atan(1.0 / (1 + tan(abs(latRad - decRad)))))) // Shafi approx
        val maghribHA = hourAngle(90.833)
        val ishaHA = hourAngle(180 - ishaAngle)

        fun toTime(hours: Double): String {
            val h = hours.toInt().mod(24)
            val m = ((hours - hours.toInt()) * 60).toInt().coerceIn(0, 59)
            return LocalTime.of(h, m).format(timeFormatter)
        }

        return listOf(
            PrayerTime(PrayerName.FAJR, toTime(solarNoon - fajrHA / 15.0)),
            PrayerTime(PrayerName.SUNRISE, toTime(solarNoon - sunriseHA / 15.0)),
            PrayerTime(PrayerName.DHUHR, toTime(solarNoon)),
            PrayerTime(PrayerName.ASR, toTime(solarNoon + asrHA / 15.0)),
            PrayerTime(PrayerName.MAGHRIB, toTime(solarNoon + maghribHA / 15.0)),
            PrayerTime(PrayerName.ISHA, toTime(solarNoon + ishaHA / 15.0))
        )
    }

    /**
     * Sample official-style times for Slemani (for demonstration).
     * In a real app these would come from a local database of Awqaf tables.
     */
    fun officialSample(cityId: String, date: LocalDate = LocalDate.now()): List<PrayerTime>? {
        // Placeholder: real implementation would look up monthly tables
        if (cityId !in listOf("slemani", "hawler", "duhok", "kirkuk")) return null

        // Approximate sample for October (replace with real data later)
        return listOf(
            PrayerTime(PrayerName.FAJR, "04:52"),
            PrayerTime(PrayerName.SUNRISE, "06:18"),
            PrayerTime(PrayerName.DHUHR, "12:05"),
            PrayerTime(PrayerName.ASR, "15:22"),
            PrayerTime(PrayerName.MAGHRIB, "17:28"),
            PrayerTime(PrayerName.ISHA, "18:48")
        )
    }

    fun buildDailyTimes(
        cityId: String,
        latitude: Double,
        longitude: Double,
        preferOfficial: Boolean = true
    ): DailyPrayerTimes {
        val date = LocalDate.now()
        val official = if (preferOfficial) officialSample(cityId, date) else null
        val times = official ?: calculate(latitude, longitude, date)
        val source = if (official != null) TimeSource.OFFICIAL else TimeSource.CALCULATED

        return DailyPrayerTimes(
            date = date.toString(),
            hijriDate = "—", // TODO: proper Hijri conversion
            cityId = cityId,
            times = times,
            source = source
        )
    }
}
