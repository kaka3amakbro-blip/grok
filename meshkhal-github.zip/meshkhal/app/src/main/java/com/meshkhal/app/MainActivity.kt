package com.meshkhal.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.meshkhal.app.ui.navigation.MeshkhalNavHost
import com.meshkhal.app.ui.screens.settings.SettingsViewModel
import com.meshkhal.app.ui.theme.MeshkhalTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MeshkhalApp()
        }
    }
}

@Composable
fun MeshkhalApp(
    settingsViewModel: SettingsViewModel = hiltViewModel()
) {
    val darkMode by settingsViewModel.darkMode.collectAsStateWithLifecycle()
    val systemDark = isSystemInDarkTheme()
    // User preference overrides system when explicitly set; for simplicity use stored value
    // (first launch defaults to false = light, user can toggle)

    MeshkhalTheme(darkTheme = darkMode) {
        Surface(modifier = Modifier.fillMaxSize()) {
            MeshkhalNavHost()
        }
    }
}
