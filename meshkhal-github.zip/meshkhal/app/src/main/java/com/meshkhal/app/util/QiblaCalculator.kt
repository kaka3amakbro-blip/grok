package com.meshkhal.app.util

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/**
 * Calculates Qibla direction (bearing to Kaaba) from given coordinates.
 * Kaaba coordinates: 21.4225° N, 39.8262° E
 */
object QiblaCalculator {
    private const val KAABA_LAT = 21.4225
    private const val KAABA_LNG = 39.8262

    /**
     * @return bearing in degrees (0-360) from North, clockwise.
     */
    fun calculateBearing(latitude: Double, longitude: Double): Double {
        val lat1 = Math.toRadians(latitude)
        val lat2 = Math.toRadians(KAABA_LAT)
        val dLng = Math.toRadians(KAABA_LNG - longitude)

        val y = sin(dLng) * cos(lat2)
        val x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLng)
        var bearing = Math.toDegrees(atan2(y, x))
        bearing = (bearing + 360) % 360
        return bearing
    }
}
