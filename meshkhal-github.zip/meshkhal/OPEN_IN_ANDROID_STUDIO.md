# How to open Meshkhal

1. Open Android Studio (Ladybug / latest stable recommended)
2. File → Open → select this folder (`meshkhal`)
3. Let Gradle Sync finish
4. If asked about missing SDK components, install them
5. Create a virtual device or plug a phone
6. Run ▶

## First-time notes
- Launcher icon uses vector drawable (works). For production generate mipmap densities via Image Asset Studio.
- Full Quran text & real Adhan audio files are structured but need offline asset packages (Tanzil + licensed audio).
- Official Kurdistan prayer tables are sample placeholders — replace with real Awqaf data.
- Dark mode, city, language and notifications are persisted with DataStore.

## Project modules
Single-module `:app` for now. Ready to split into feature modules later.
